使用方法
1. 解压整个文件夹。
2. 双击 index.html 打开第一页。
3. Previous / Next 切换三位同学的作品页；Gallery 进入目录。
4. 在编辑器里修改各 HTML 文件和 main.css。所有文件及 assets 文件夹保持在一起。

无须安装软件，无须 JavaScript，离线也可以打开。反应按钮采用 HTML radio + CSS，切页后不保存选择。
参考作品图裁自提供的截图，清晰度有限；可以用同名高清图片替换 assets 内的图片。
两张作品预览用 CSS 重新绘制。点击预览或作品按钮，会在带固定返回栏的页面中打开组员原网站：
Julia: https://0505dej.github.io/snail/
Amber: https://xuyucheng28-hub.github.io/artwork-website-final2/
访问组员网站需要联网。Previous / Next 仍在本地展览页面之间切换。

作品页面左上角有 Back to exhibition / 返回展览 按钮，点击返回对应介绍页。
如果网站不允许嵌入，点击右上角 Open original，在新标签页访问；关闭该标签页即可回到返回栏页面。
